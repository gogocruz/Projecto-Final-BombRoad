#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>

// gcc main.c -Wall -Wextra -Wpedantic -std=c99 -Wvla
//./a.out

void menu(){ // funcao com o MENU
        printf("+-----------------------------------------------------\n");
        printf("read <filename>     - read input file\n");
        printf("show                - show the mine map\n");
        printf("trigger <x> <y>     - trigger mine at <x> <y>\n");
        printf("plant <x> <y>       - place armed mine at <x> <y>\n");
        printf("export <filename>   - save file with current map\n");
        printf("quit                - exit program\n");
        printf("sos                 - show menu\n");
        printf("+-----------------------------------------------------\n");
}

int main(void){ // Funcao principal
  
    char opc[7], fname[64],linha[101];
    int x, y;
    char mapa[25][25];// criacao com as limitacoes do mapa


// criar mapa
    for (x=0;x<25;x++)
          {
                for(y=0;y<25;y++)
              {
                mapa[x][y] = '_';
              }
          }

    menu(); //
  do{  
    printf("\n>"); 
    fgets(linha, 101, stdin);
// comando read 
    if (!strncmp(linha,"read",4)) {
        sscanf(linha, "%s %s", opc, fname);
        FILE * fpointer = fopen(fname,"r");
        if(fpointer == NULL){
            printf("Error opening file\n");
            continue;
        }
        else
        {
            for (int f=0;(!feof(fpointer));f++){
              fscanf(fpointer, "%d %d", &x, &y);
              if (x > 24 || y > 24){
                printf("File is corrupted\n");
                break;
              }
              else 
              {
                mapa[x][y] = '.';
              }
            }
         
        }
        fclose(fpointer);
    }
    // comando show
    else if (!strncmp(linha,"show",4)) {
    
      for (x=0;x<25;x++)
          {
                for(y=0;y<25;y++)
              {
                printf("%c",mapa[x][y]);
              }
              printf("\n");
          }
    }
  // comando trigger 
    else if (!strncmp(linha,"trigger",7)){ 
        sscanf(linha,"%s %d %d", opc, &x, &y);
        if((x > 24) || (y > 24)){
          printf("Invalid coordinate\n");
          continue;
        }
        if (mapa[x][y] == '_'){  // nao existe mina
            printf("No mine at specified coordinate\n");
            continue;
        } 
        if (mapa[x][y] == '.'){ // bomba passa de armed para off
           mapa[x][y] = '*'; 
        }
        if (mapa[x][y] == '*'){ // ignora a bomba armada
           continue;
        }           
    }
    // comando plant 
    else if(!strncmp(linha,"plant",5)){
        sscanf(linha,"%s %d %d", opc, &x, &y);
        if((x > 24) || (y > 24)){
          printf("Invalid coordinate\n");
          continue;
        } 

        if (mapa[x][y] == '*'){ // Plant off > arm//
           mapa[x][y] = '.';
        }
        if (mapa[x][y] == '_') // Colocar mina estado arm//
          mapa[x][y] = '.'; 
        if (mapa[x][y] == '.') // Simplesmente ignora a mina//
            continue;
    } 
    // comando export 
    else if(!strncmp(linha,"export",6)){
          strncpy(linha, linha+7, strlen(linha));
          linha[strlen(linha)-1] = '\0';
          FILE * fpointer = fopen(linha, "w");
          for(int i = 0; i <=24; i++)
          {
            for(int j = 0; j <=24; j++)
            {
              if (mapa[i][j] == '.' || mapa[i][j] == '*')
              {
                fprintf(fpointer,"%d %d\n", i, j);
              }
            }
          }
          fclose(fpointer);
    }
    // comando quit
    else if (!strncmp(linha,"quit",4)){ //quit do programa
          sscanf(linha,"%s", opc);
    }
    // comando sos 
    else if(!strncmp(linha,"sos",3)){
      menu(); // Abre o menu de novo
    continue;  
    }  

  } while ((strcmp(opc,"quit"))!= 0) ;

  return 0;
}