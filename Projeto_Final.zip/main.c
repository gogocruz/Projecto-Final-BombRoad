#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>
// Usar estes comandos na shell
// gcc main.c -Wall -Wextra -Wpedantic -std=c99 -Wvla
//./a.out

typedef struct s_elemento {
	int tempo;
  int x;
  int y;
	struct s_elemento * next;
} elemento;

typedef elemento * lista;

void Apagar (lista *);

int Inserir (lista *, elemento);

void menu(){ // funcao com o MENU
        printf("+-----------------------------------------------------\n");
        printf("read <filename> - read input file\n");
        printf("show - show the mine map\n");
        printf("trigger <x> <y> - trigger mine at <x> <y>\n");
        printf("log <x> <y> - trigger mine at <x> <y>\n");
        printf("plant <x> <y> - place armed mine at <x> <y>\n");
        printf("export <filename> - save file with current map\n");
        printf("quit - exit program\n");
        printf("sos - show menu\n");
        printf("+-----------------------------------------------------\n");
}

int Inserir (lista * lista, elemento p)
{
  elemento * t;
	elemento * aux = (elemento *) malloc(sizeof(elemento));
	if (aux == NULL)
		return 0;		// ERROR: out of memory
	aux -> tempo = p.tempo;
  aux -> x = p.x;
  aux -> y = p.y;
	aux -> next = NULL;

	if (*lista == NULL)
	{
		*lista = aux;
		return 1;
	}

	// percorrer a lista ate que o next seja NULL
	for (t = *lista ; t->tempo < aux -> tempo ; t = t -> next)
		; 
  aux -> next = t;
	t->next = aux;
	return 1;			// SUCCESS
}

void Apagar (lista * lista)
{
	elemento * aux;
	if (*lista == NULL)	// lista esta vazia
		return;

	aux = *lista;
	*lista = aux -> next; // alteramos o primeiro

	// libertamos a memoria que deixa de ser necessaria
	free(aux);
}

int main(void){ // Funcao principal
  
    char opc[7], fname[64],linha[101];
    int x, y;
    int nrows = 25;
    int ncols = 25;

// criar mapa
char **mapa = (char **) malloc(nrows * sizeof(char *));

if (mapa == NULL)
{
    puts("Error: Out of Memory");
    exit(1);
}
// para cada elemento do vector, aloca um vector com tamanho ncols
int i,j;

for(i = 0; i < nrows; i++)
{
    mapa[i] = malloc(ncols * sizeof(char));
    if (mapa[i] == NULL)
    {
        puts("Error: Out of Memory");
        exit(1);
    }
} 
for(i = 0; i < nrows; i++){
  for(j = 0; j < ncols; j++){
    mapa[i][j] = '_';
  }
}  
// a partir daqui pode aceder aos elementos da matriz da forma habitual mapa[x][y]
    menu(); //
  do{  
    printf("\n>"); 
    fgets(linha, 101, stdin);
  
// comando read 
    if (!strncmp(linha,"read",4)) {
      sscanf(linha, "%s %s", opc, fname);
      FILE * fpointer = fopen(fname,"r");
      if(fpointer == NULL){
          printf("Error opening file\n");
        continue;
      }
        else{  
          
          int oldrows = nrows, oldcols = ncols;
          fscanf(fpointer,"%d %d", &nrows, &ncols);

          if(nrows != oldrows || ncols != oldcols){
            mapa = realloc(mapa, nrows * sizeof(char *));
            if (mapa == NULL){
              puts("out of memory");
              exit(1);
            }
            for(int i = 0; i < nrows; i ++){
              mapa[i] = realloc(mapa[i], ncols * sizeof(char));
              if (mapa[i] == NULL){
                puts("out of memory");
              exit(1);
            }              
            }
          }
          for (int f=0;(!feof(fpointer));f++){
            fscanf(fpointer, "%d %d", &x, &y);
            if (x > nrows || y > ncols){
              printf("File is corrupted\n");
            break;
            }
            else 
            {
              mapa[x][y] = '.';
            }
          }     
      }
      fclose(fpointer);
    }

    // comando show
    else if (!strncmp(linha,"show",4)) {
    
      for (x=0;x<25;x++)
          {
                for(y=0;y<25;y++)
              {
                printf("%c",mapa[x][y]);
              }
              printf("\n");
          }
    }

  // comando trigger 
      else if (!strncmp(linha,"trigger",7)){ 
        sscanf(linha,"%s %d %d", opc, &x, &y);
        if((x >= nrows || x < 0) || (y >= ncols || y < 0)){
          printf("Invalid coordinate\n");
          continue;
        }
        if (mapa[x][y] == '_'){  // nao existe mina
            printf("No mine at specified coordinate\n");
            continue;
        } 
        if (mapa[x][y] == '.'){ // bomba passa de armed para off
          elemento explosao;
          lista explosoes = NULL;
          explosao.tempo = 0;
          explosao.x = x;
          explosao.y = y;
          Inserir(&explosoes, explosao);

          while(explosoes != NULL)
           {
            mapa[explosoes[0].x][explosoes[0].y] = '*';
            if (explosoes[0].x + 1 < nrows)
            {
              if (mapa[explosoes[0].x + 1][explosoes[0].y] == '.')
              {
                elemento adjacente;
                adjacente.tempo = explosoes[0].tempo + 10;
                adjacente.x = explosoes[0].x + 1;
                adjacente.y = explosoes[0].y;
                Inserir(&explosoes, adjacente);
              }
            }
            if (explosoes[0].y + 1 < ncols)
            {
              if (mapa[explosoes[0].x][explosoes[0].y + 1] == '.')
              {
                elemento adjacente;
                adjacente.tempo = explosoes[0].tempo + 10;
                adjacente.x = explosoes[0].x;
                adjacente.y = explosoes[0].y + 1;
               Inserir(&explosoes, adjacente);
              }
            }
            if (explosoes[0].x + 1 < nrows && explosoes[0].y + 1 < ncols)
            {
              if (mapa[explosoes[0].x + 1][explosoes[0].y + 1] == '.')
              {
                elemento adjacente;
                adjacente.tempo = explosoes[0].tempo + 15;
                adjacente.x = explosoes[0].x + 1;
                adjacente.y = explosoes[0].y + 1;
                Inserir(&explosoes, adjacente);
              }
            }
            if (explosoes[0].x - 1 >= 0){
              if (mapa[explosoes[0].x - 1][explosoes[0].y] == '.')
              {
                elemento adjacente;
                adjacente.tempo = explosoes[0].tempo + 10;
                adjacente.x = explosoes[0].x - 1;
                adjacente.y = explosoes[0].y;
               Inserir(&explosoes, adjacente);
              }
              }

              if (explosoes[0].y - 1 >= 0)
              {
                if (mapa[explosoes[0].x][explosoes[0].y - 1] == '.')
                {
                  elemento adjacente;
                  adjacente.tempo = explosoes[0].tempo + 10;
                  adjacente.x = explosoes[0].x;
                  adjacente.y = explosoes[0].y - 1;
                  Inserir(&explosoes, adjacente);
                }
              }
              if (explosoes[0].x - 1 >= 0 && explosoes[0].y - 1 >= 0)
              {
                if (mapa[explosoes[0].x - 1][explosoes[0].y - 1] == '.')
                {
                  elemento adjacente;
                  adjacente.tempo = explosoes[0].tempo + 15;
                  adjacente.x = explosoes[0].x - 1;
                  adjacente.y = explosoes[0].y - 1;
                  Inserir(&explosoes, adjacente);
                }
              }
              if (explosoes[0].x + 1 < nrows && explosoes[0].y - 1 >= 0)
              {
                if (mapa[explosoes[0].x + 1][explosoes[0].y - 1] == '.')
                {
                  elemento adjacente;
                  adjacente.tempo = explosoes[0].tempo + 15;
                  adjacente.x = explosoes[0].x + 1;
                  adjacente.y = explosoes[0].y - 1;
                  Inserir(&explosoes, adjacente);
                }
              }
              if (explosoes[0].x - 1 >= 0 && explosoes[0].y + 1 < ncols)
              {
                if (mapa[explosoes[0].x - 1][explosoes[0].y + 1] == '.')
                {
                  elemento adjacente;
                  adjacente.tempo = explosoes[0].tempo + 10;
                  adjacente.x = explosoes[0].x - 1;
                  adjacente.y = explosoes[0].y + 1;
                  Inserir(&explosoes, adjacente);
                }
              }
              Apagar(&explosoes);

        if (mapa[x][y] == '*'){ // ignora a bomba armada
           continue;
        }           
      }
    }              
    // comand Log
      else if (!strncmp(linha,"log",3)){ 
        sscanf(linha,"%s %d %d", opc, &x, &y);
        if((x >= nrows || x < 0) || (y >= ncols || y < 0)){
          printf("Invalid coordinate\n");
          continue;
        }
        if (mapa[x][y] == '_'){  // nao existe mina
            printf("No mine at specified coordinate\n");
            continue;
        } 
        if (mapa[x][y] == '.'){ // bomba passa de armed para off
          elemento explosao;
          lista explosoes = NULL;
          explosao.tempo = 0;
          explosao.x = x;
          explosao.y = y;
          Inserir(&explosoes, explosao);
   
          while(explosoes != NULL)
           {
            mapa[explosoes[0].x][explosoes[0].y] = '*';
            if (explosoes[0].x + 1 < nrows)
            {
              if (mapa[explosoes[0].x + 1][explosoes[0].y] == '.')
              {
                elemento adjacente;
                adjacente.tempo = explosoes[0].tempo + 10;
                adjacente.x = explosoes[0].x + 1;
                adjacente.y = explosoes[0].y;
                Inserir(&explosoes, adjacente);
              }
            }
            if (explosoes[0].y + 1 < ncols)
            {
              if (mapa[explosoes[0].x][explosoes[0].y + 1] == '.')
              {
                elemento adjacente;
                adjacente.tempo = explosoes[0].tempo + 10;
                adjacente.x = explosoes[0].x;
                adjacente.y = explosoes[0].y + 1;
               Inserir(&explosoes, adjacente);
              }
            }
            if (explosoes[0].x + 1 < nrows && explosoes[0].y + 1 < ncols)
            {
              if (mapa[explosoes[0].x + 1][explosoes[0].y + 1] == '.')
              {
                elemento adjacente;
                adjacente.tempo = explosoes[0].tempo + 15;
                adjacente.x = explosoes[0].x + 1;
                adjacente.y = explosoes[0].y + 1;
                Inserir(&explosoes, adjacente);
              }
            }
            if (explosoes[0].x - 1 >= 0){
              if (mapa[explosoes[0].x - 1][explosoes[0].y] == '.')
              {
                elemento adjacente;
                adjacente.tempo = explosoes[0].tempo + 10;
                adjacente.x = explosoes[0].x - 1;
                adjacente.y = explosoes[0].y;
                Inserir(&explosoes, adjacente);
              }
              }

              if (explosoes[0].y - 1 >= 0)
              {
                if (mapa[explosoes[0].x][explosoes[0].y - 1] == '.')
                {
                  elemento adjacente;
                  adjacente.tempo = explosoes[0].tempo + 10;
                  adjacente.x = explosoes[0].x;
                  adjacente.y = explosoes[0].y - 1;
                  Inserir(&explosoes, adjacente);
                }
              }
              if (explosoes[0].x - 1 >= 0 && explosoes[0].y - 1 >= 0)
              {
                if (mapa[explosoes[0].x - 1][explosoes[0].y - 1] == '.')
                {
                  elemento adjacente;
                  adjacente.tempo = explosoes[0].tempo + 15;
                  adjacente.x = explosoes[0].x - 1;
                  adjacente.y = explosoes[0].y - 1;
                  Inserir(&explosoes, adjacente);
                }
              }
              if (explosoes[0].x + 1 < nrows && explosoes[0].y - 1 >= 0)
              {
                if (mapa[explosoes[0].x + 1][explosoes[0].y - 1] == '.')
                {
                  elemento adjacente;
                  adjacente.tempo = explosoes[0].tempo + 15;
                  adjacente.x = explosoes[0].x + 1;
                  adjacente.y = explosoes[0].y - 1;
                  Inserir(&explosoes, adjacente);
                }
              }
              if (explosoes[0].x - 1 >= 0 && explosoes[0].y + 1 < ncols)
              {
                if (mapa[explosoes[0].x - 1][explosoes[0].y + 1] == '.')
                {
                  elemento adjacente;
                  adjacente.tempo = explosoes[0].tempo + 10;
                  adjacente.x = explosoes[0].x - 1;
                  adjacente.y = explosoes[0].y + 1;
                  Inserir(&explosoes, adjacente);
                }
              }
              Apagar(&explosoes);
            }
          }
        }
        if (mapa[x][y] == '*'){ // ignora a bomba armada
           continue;
        } 
      }         
      

    // comando plant 
    else if(!strncmp(linha,"plant",5)){
        sscanf(linha,"%s %d %d", opc, &x, &y);
        if((x >= nrows || x < 0) || (y >= ncols || y < 0)){
          printf("Invalid coordinate\n");
          continue;
        } 

        if (mapa[x][y] == '*'){ // Plant off > arm//
           mapa[x][y] = '.';
        }
        if (mapa[x][y] == '_'){ // Colocar mina estado arm//
          mapa[x][y] = '.'; 
        }
        if (mapa[x][y] == '.'){ // Simplesmente ignora a mina//
            continue;
        }
    }   
    // comando export 
    else if(!strncmp(linha,"export",6)){
          strncpy(linha, linha+7, strlen(linha));
          linha[strlen(linha)-1] = '\0';
          FILE * fpointer = fopen(linha, "w");
          fprintf(fpointer, "%d %d\n", nrows, ncols);
          for(int i = 0; i < nrows; i++)
          {
            for(int j = 0; j < ncols; j++)
            {
              if (mapa[i][j] == '.' || mapa[i][j] == '*')
              {
                fprintf(fpointer,"%d %d\n", i, j);
              }
            }
          }
          fclose(fpointer);
    }
    // comando quit
    else if (!strncmp(linha,"quit",4)){ //quit do programa
          sscanf(linha,"%s", opc);
    }
    // comando sos 
    else if(!strncmp(linha,"sos",3)){
      menu(); // Abre o menu de novo
    continue;  
    }  
  else{
    printf("Invalid command!\n");
  }
  }while ((strcmp(opc,"quit"))!= 0) ;

  return 0;
}